using IgnisMercado.Areas.Identity.Data;

namespace IgnisMercado.Models 
{ 
    public class Administrador : ApplicationUser
    { 
        /// <summary>
        /// Para RazorPages: constructor sin argumentos.
        /// </summary>
        public Administrador() 
        {
        }

        // /// <summary>
        // /// Para RazorPages: atributo PrimaryKey de la tabla.
        // /// </summary>
        // public new int Id { get; set; } 

    }
}
