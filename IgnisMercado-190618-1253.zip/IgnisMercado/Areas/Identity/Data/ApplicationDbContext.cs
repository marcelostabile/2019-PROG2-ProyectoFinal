using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using IgnisMercado;

namespace IgnisMercado.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
        }

        public DbSet<IgnisMercado.Administrador> Administrador { get; set; }

        public DbSet<IgnisMercado.Cliente> Cliente { get; set; }

        public DbSet<IgnisMercado.Tecnico> Tecnico { get; set; }

        public DbSet<IgnisMercado.Solicitud> Solicitud { get; set; }

        public DbSet<IgnisMercado.Proyecto> Proyecto { get; set; }

        public DbSet<IgnisMercado.Rol> Rol { get; set; }
    }
}
