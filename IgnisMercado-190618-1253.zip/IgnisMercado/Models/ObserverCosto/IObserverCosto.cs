namespace IgnisMercado 
{
    public interface IObserverCosto
    {
        void ActualizarCostoSolicitudActiva();
    }

}
