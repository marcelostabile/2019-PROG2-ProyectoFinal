namespace IgnisMercado 
{
    public interface ICosto 
    {
        int CalcularCostoSolicitud(int ModoDeContrato, int HorasContratadas,string NivelExperiencia);
    }
    
}