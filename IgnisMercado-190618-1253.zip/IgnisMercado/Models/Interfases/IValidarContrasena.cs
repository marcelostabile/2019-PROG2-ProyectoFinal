namespace IgnisMercado 
{
    /// <summary>
    /// Implementada por la clase ValidarContrasena.
    /// </summary>
    public interface IValidarContrasena 
    {
        bool EsUnaContrasenaValida(string valor);
    }
}