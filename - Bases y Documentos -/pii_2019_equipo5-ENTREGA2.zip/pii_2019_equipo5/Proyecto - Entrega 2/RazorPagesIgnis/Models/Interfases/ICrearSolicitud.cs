namespace RazorPagesIgnis 
{
    /// <summary>
    /// Implementada por la clase Proyecto.
    /// </summary>
    public interface ICrearSolicitud
    {
        void AgregarSolicitud(Solicitud nuevaSolicitud);

    }
}
