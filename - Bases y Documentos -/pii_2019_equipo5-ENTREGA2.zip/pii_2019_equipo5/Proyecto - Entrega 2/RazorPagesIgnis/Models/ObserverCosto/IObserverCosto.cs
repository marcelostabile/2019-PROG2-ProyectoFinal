namespace RazorPagesIgnis 
{
    public interface IObserverCosto
    {
        void ActualizarCostoSolicitudesActivas();
    }

}
