using IgnisMercado.Areas.Identity.Data;

namespace IgnisMercado.Models 
{ 
    public class Administrador : ApplicationUser
    { 
        /// <summary>
        /// Para RazorPages: constructor sin argumentos.
        /// </summary>
        public Administrador() 
        {
        }

    }
}
