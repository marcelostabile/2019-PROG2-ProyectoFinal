namespace IgnisMercado.Models 
{
    public interface IObserverCosto
    {
        void ActualizarCostoSolicitudActiva();
    }

}
