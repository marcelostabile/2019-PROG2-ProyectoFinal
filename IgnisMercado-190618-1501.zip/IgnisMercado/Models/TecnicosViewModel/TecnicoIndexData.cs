using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IgnisMercado.Models;

namespace IgnisMercado.IgnisViewModel
{
    public class MovieIndexData
    {
        public IEnumerable<Tecnico> Tecnicos { get; set; } 
    }
}